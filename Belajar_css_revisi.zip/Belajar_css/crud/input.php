<?php
session_start();
include 'koneksi.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nis     = mysqli_real_escape_string($koneksi, $_POST["nis"]);
  $nomor   = mysqli_real_escape_string($koneksi, $_POST["nomor"]);
  $tanggal = mysqli_real_escape_string($koneksi, $_POST["tanggal"]);
  $ikut    = mysqli_real_escape_string($koneksi, $_POST["ikut"]);

  $query = "INSERT INTO tbl_siswa (nis, nomor_test, tanggal_tes, bersedia_mengikutites) 
            VALUES ('$nis', '$nomor', '$tanggal', '$ikut')";
  
  if (mysqli_query($koneksi, $query)) {
    echo "<script>alert('Data berhasil disimpan'); window.location.href='tabel.php';</script>";
  } else {
    echo "Gagal menyimpan data: " . mysqli_error($koneksi);
  }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Input Data Siswa</title>
    <link rel="stylesheet" href="input.css">
</head>

<body>
    <!-- Header -->
    <div class="header">
        <img src="../GambarTB2.jpg" alt="Foto User" class="user-image">
        <span class="welcome-text">Selamat Datang, Haekal |</span>
        <a href="../login.php" class="logout-btn">Logout</a>
    </div>

    <!-- Navigasi -->
    <div class="navigation">
        <button><a href="tabel.php">Data Tes</a></button>
    </div>

    <!-- Judul Form -->
    <h2 class="form-title">Form Input Data Siswa</h2>

    <!-- Form -->
    <div class="form-container">
        <form method="POST" action="">
            <label for="nis">NIS:</label>
            <input type="number" id="nis" name="nis" required>

            <label for="nomor">Nomor Tes:</label>
            <input type="number" id="nomor" name="nomor" required>

            <label for="tanggal">Tanggal Tes:</label>
            <input type="date" id="tanggal" name="tanggal" required>

            <label for="ikut">Bersedia Mengikuti Tes:</label>
            <select id="ikut" name="ikut" required>
                <option value="">-- Pilih --</option>
                <option value="bersedia">Bersedia</option>
                <option value="tidak bersedia">Tidak Bersedia</option>
            </select>

            <button type="submit" class="submit-btn">Simpan Data</button>
        </form>
    </div>
</body>

</html>