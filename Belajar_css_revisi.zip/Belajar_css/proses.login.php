<?php
session_start();
include 'koneksi.php';

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$username = $_POST['username'];
$password = $_POST['password'];
$status   = $_POST['status'];

// Debug: tampilkan input yang dikirim
echo "Username: $username<br>";
echo "Password: $password<br>";
echo "Status: $status<br>";

$query = "SELECT * FROM tbl_user WHERE username = '$username' AND password = '$password' AND status = '$status'";
echo "Query: $query<br>";

$result = mysqli_query($koneksi, $query);

if (mysqli_num_rows($result) == 1) {
    $data = mysqli_fetch_assoc($result);
    $_SESSION['id_user']  = $data['id_user'];
    $_SESSION['username'] = $data['username'];
    $_SESSION['status']   = $data['status'];
    header("Location: form.input.php");
    exit();
} else {
    echo "<script>alert('Login gagal! Periksa kembali username, password, dan peran Anda.'); window.location.href='login.php';</script>";
}
?>